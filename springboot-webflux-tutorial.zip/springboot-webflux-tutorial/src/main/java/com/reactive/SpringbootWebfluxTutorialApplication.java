package com.reactive;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootWebfluxTutorialApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootWebfluxTutorialApplication.class, args);
	}

}
